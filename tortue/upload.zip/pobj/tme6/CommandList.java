package pobj.tme6;

import java.util.ArrayList;
import java.util.List;

public class CommandList implements ICommand {
	List<ICommand> listCommand ;
	
	public CommandList() {
		this.listCommand = new ArrayList<ICommand>();
	}
	
	public void addCommand(ICommand command) {
		listCommand.add(command);
	}
	
	public void execute(IColorTurtle turtle) {
		for (ICommand command : listCommand)
			command.execute(turtle);
	}


}
