package pobj.tme6;

public class SaveSubstTurtle extends SaveTurtle {
	private ICommand subst;
	
	public SaveSubstTurtle(ICommand subst) {
		super();
		this.subst = subst;
	}
	
	public void move(int length) {
		listCommand.addCommand(subst);

	}
}
