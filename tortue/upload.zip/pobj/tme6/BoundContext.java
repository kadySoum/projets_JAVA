package pobj.tme6;

import javafx.scene.paint.Color;

public class BoundContext implements IContext {
	private int minX = (int) Float.POSITIVE_INFINITY;
	private int maxX = 0; 
	private int minY = (int) Float.POSITIVE_INFINITY;
	private int maxY = 0;

	@Override
	public void drawLine(int x1, int y1, int x2, int y2, Color color) {
		int minX = Math.min(x1, x2);
		int maxX = Math.max(x1, x2);
		int minY = Math.min(y1, y2);
		int maxY = Math.max(y1, y2);
		if (minX < this.minX)
			this.minX = minX;
		if (maxX > this.maxX) 
			this.maxX = maxX;
		if (minY < this.minY)
			this.minY = minY;
		if (maxY> this.maxY)
			this.maxY= maxY;
	}
	
	public int getMinX() {
		return minX;
	}
	
	public int getMaxX() {
		return maxX;
	}
	
	public int getMinY() {
		return minY;
	}
	
	public int getMaxY() {
		return maxY;
	}

}
