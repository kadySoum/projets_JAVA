package pobj.tme6;

import javafx.scene.paint.Color;

public class SaveTurtle implements IColorTurtle {
	protected CommandList listCommand;
	
	
	public SaveTurtle() {
		listCommand = new CommandList();
	}

	@Override
	public void move(int length) {
		listCommand.addCommand(new CommandMove(length));

	}

	@Override
	public void turn(int angle) {
		listCommand.addCommand(new CommandTurn(angle));
	}

	@Override
	public void up() {
		listCommand.addCommand(new CommandUp());
	}

	@Override
	public void down() {
		listCommand.addCommand(new CommandDown());
	}

	@Override
	public void setColor(Color color) {
		listCommand.addCommand(new CommandSetColor(color));
	}

	public CommandList getCommand(){
		return listCommand;
	}
}
