package pobj.tme6;

public class Substitution {

	public static ICommand substitute(ICommand org, ICommand subst) {
		SaveSubstTurtle turtle = new SaveSubstTurtle(subst);
		org.execute(turtle);
		return turtle.getCommand();
	}

}
